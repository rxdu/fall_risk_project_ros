#define EKIGA_REVISION "unknown"
